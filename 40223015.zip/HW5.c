// Helia Bayat    40223015
#include <stdio.h>
int main()
{
    int n, i, k, j, h;
    printf("Enter a positive integer number:\n");
    scanf("%d", &n);
    char A[n + 1];
    printf("\nEnter a phrase with n characters:\n");
    getchar();
    for (k = 0; k < n; k++)
        scanf("%c", &A[k]);

    for (i = 0; i < n; i++)
    {
        if (A[i] == A[i + 1])
        {
            for (j = 0; j < n - i - 2; j++)
                A[i + j] = A[i + j + 2];
            i = -1;
            n = n - 2;
            for (h = 0; h < n; h++)
                printf("%c", A[h]);
            printf("\n");
        }
    }

    return 0;
}